// import { StrictMode } from "react";
// import { createRoot } from "react-dom/client";
// import "./index.css";
// import App from "./App.jsx";
// import Contact from "./Components/Contact.jsx";
// import { createBrowserRouter, RouterProvider } from "react-router-dom";
// import About from "../practice/src/Components/About.jsx";

// const router = createBrowserRouter([
//   {
//     path: "/",
//     element: <App />,
//   },
//   {
//     path: "/About",
//     element: <About />,
//   },
//   {
//     path: "/Contact",
//     element: <Contact />,
//   },
// ]);

// createRoot(document.getElementById("root")).render(
//   <StrictMode>
//     <RouterProvider router={router} />
//     <App/>
//   </StrictMode>
// );
import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import { Provider } from "react-redux";
import store from "./Components/store";  

ReactDOM.createRoot(document.getElementById("root")).render(
  <Provider store={store}>
    <App />
  </Provider>
);
