function Child({ onButtonClick }) {
  return <button onClick={onButtonClick}>Increment Count</button>;
}

export default Child;
