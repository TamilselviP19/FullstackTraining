import { useEffect, useState,useRef } from "react";
import img2 from "../assets/img2.png";

function UseState(props) {
  const [purchased, setPurchased] = useState(true);
  const [discountAmt, setDiscountAmt] = useState(props.price);
 

  function buy() {
    setPurchased(false);
   
  }

  function discount(val) {
    let amount = discountAmt - val;
    setDiscountAmt(amount);
  }

//  useEffect(()=>{
//  console.log("useEffect")
 
//  })

//   useEffect(()=>{
//   console.log("useEffect for discount")
//  },[discount])

 
//   useEffect(()=>{
//   console.log("useEffect for empty dependency")
//  },[])


  return (
    <>
    <div className="container ">
      <div className="row justify-content-center">
        <div className="col-md-4">
      <div className="card">
        <img src={img2} className="img-fluid"></img>
        <h2 className="card-body">{props.name}</h2>
        <p>price:{discountAmt}</p>
        <button className="btn btn-primary" onClick={buy}>
          Buy Now
        </button>
        <br/>
        <button className="btn btn-danger" onClick={() => discount(20)}>
          Discount
        </button>
        <br/>
        <br/>
        <b><p>{purchased ? "⏲️Get it Now" : " ✅Already Purchased"}</p></b>
      </div>
      </div>
      </div>
      </div>
    </>
  );
}
export default UseState