import { useState, useEffect } from "react";

function Cleanup() {
  const [count, setCount] = useState(0);

  useEffect(() => {
    
    const intervalId = setInterval(() => {
      setCount((prev) => prev + 1);
    }, 1000);

    console.log("Timer started");

   
    return () => {
      clearInterval(intervalId); 
      console.log("Timer stopped");
    };
  }, []); 

  return (
    <div>
      <h2>Count: {count}</h2>
    </div>
  );
}

export default Cleanup;
