
import UserContext from "../Components/UserContext";
import ClickEvent from "./ClickEvent";
import PropsDemo from "./PropsDemo";
import ShowName from "./ShowName";

function Home() {
  const userName = "Welcome Bharathi";

  return (
    <>
      <h4>Home Page</h4>
      <UserContext.Provider value={userName}>
        <ShowName/>
        <ClickEvent/>
      </UserContext.Provider>
    </>
  );
}

export default Home;
