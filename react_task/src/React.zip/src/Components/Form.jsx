import { useState,useContext } from "react";


function Form() {
  const [formData, setFormData] = useState({
    name: "",
    username: "",
    email: "",
    password: ""
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);

  const [historyData, setHistoryData] = useState([]); // for history

  function handleChange(e) {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setError(false);

    try {
      const response = await fetch("http://localhost:3500/items", {
        method: "POST",
        body: JSON.stringify(formData)
      });

      if (!response) {
        throw new Error("Failed to submit");
      }

      alert("User added successfully!");

      setFormData({
        name: "",
        username: "",
        email: "",
        password: ""
      });
    } catch (err) {
      console.error(err);
      setError(true);
    } finally {
      setLoading(false);
    }
  }

  async function handleHistory() {
    setLoading(true);
    setError(false);

    try {
      const res = await fetch("http://localhost:3500/items");
      if (!res) {
        throw new Error("Failed to fetch history");
      }

      const data = await res.json();
      setHistoryData(data);
    } catch (err) {
      console.error(err);
      setError(true);
    } finally {
      setLoading(false);
    }
  }

  if (loading) return <h2>Loading…</h2>;
  if (error) return <h2>Error fetching data</h2>;

  return (
    <>
      <form onSubmit={handleSubmit} className="form">
        <h3>Fill the Form</h3>

        <label>Name: </label>
        <input
          type="text"
          name="name"
          value={formData.name}
          onChange={handleChange}
          required
        />
        <br /><br />

        <label>Username: </label>
        <input
          type="text"
          name="username"
          value={formData.username}
          onChange={handleChange}
          required
        />
        <br /><br />

        <label>Email: </label>
        <input
          type="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          required
        />
        <br /><br />

        <label>Password: </label>
        <input
          type="password"
          name="password"
          value={formData.password}
          onChange={handleChange}
          required
        />
        <br /><br />

        <button type="submit" style={{ marginRight: "5px" }}>Submit</button>
        <button type="button" onClick={handleHistory}>History</button>
      </form>

      {/* Display History if Available */}
      {historyData.length > 0 && (
        <>
          <h3>Stored Users</h3>
          <ul>
            {historyData.map((user, index) => (
              <li key={index}>
                <p>Name:{user.name}</p>
                <p>email:{user.email}</p>
                <p>password:{user.password}</p>
              </li>
            ))}
          </ul>
        </>
      )}
    </>
  );
}

export default Form