import { configureStore } from '@reduxjs/toolkit';
import counterReducers from './counterSlice';
import scoreReducer from './scoreSlice';
import inputReducer from './inputSlice';

const store = configureStore({
  reducer: {
    counter: counterReducers,
    score: scoreReducer,
    input : inputReducer
  }
});

export default store;
