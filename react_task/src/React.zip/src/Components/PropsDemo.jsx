
function PropsDemo(props) {

  return (
    <>
      <p>Hello {props.name}</p>
       
    </>
  );
}
export default PropsDemo;
