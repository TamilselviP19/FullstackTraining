import { useContext } from "react";
import UserContext from "../Components/UserContext";

function ShowName() {
  const userName = useContext(UserContext);

  return (
    <h3>Hello, {userName}!</h3>
  );
}

export default ShowName;
