import React, { useState, useEffect } from "react";
import Demo from "./Demo";

function Course() {
  const [data, setData] = useState([]);
  const [error, setError] = useState(false);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const response = await fetch("http://localhost:3000/items");
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        const result = await response.json();
        setData(result);
      } catch (err) {
        setError(true);
        console.error(err);
      }
    };

    fetchUser();
  }, []);

  // Show error if fetch failed
  if (error) return <h2>Failed to load data.</h2>;

  return (
    <>
      {data.map((item, index) => (
        <div className="card" key={index}>
          <img src={item.img2} alt="Course" />
          <h3>{item.name}</h3>
          <h2>{item.price}</h2>
        </div>
      ))}
      <Demo company="Zoho" />
    </>
  );
}

export default Course;
