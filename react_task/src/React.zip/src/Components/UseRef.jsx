// component doesnot re-render / how to update the variable without useState
import { useEffect, useRef, useState } from "react";
function UseRef() {
  const [count, setCount] = useState(0);
  let refCount = useRef(0);

  function inc() {
   // setCount(count+1)
    refCount.current++;
    //console.log("count"+ count)
    console.log("refcount"+refCount.current)
  }
  useEffect(() => {
    console.log(refCount);
  }, [count]);

  return (
    <>
      <h2>{refCount.current}</h2>
      <button onClick={inc}>Click</button>
      <button
        onClick={() => {
          setCount(refCount.current);
        }}
      >
        update
      </button>
    </>
  );
}
export default UseRef;
