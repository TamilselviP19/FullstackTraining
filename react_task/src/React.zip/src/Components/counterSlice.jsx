import { createSlice } from "@reduxjs/toolkit";

const counterSlice = createSlice({
  name: "counter",
  initialState: {
    value: 0,
    history: [0],
    like: true,
  
  },
  reducers: {
    increment: (state) => {
      state.value += 1;
      state.history.push(state.value);
    },
    decrement: (state) => {
      state.value -= 1;
      state.history.push(state.value);
    },
    reset: (state) => {
      state.value = 0;
      state.history=[0];
     
    },
    UnDo: (state) => {
      if (state.history.length > 1) {
        state.history.pop();
        state.value = state.history[state.history.length - 1];
      }
    },
    toggleLike: (state) => {
      state.like = !state.like;  
    },
  },
});

export const { increment, decrement, reset, UnDo, toggleLike } = counterSlice.actions;
export default counterSlice.reducer;
