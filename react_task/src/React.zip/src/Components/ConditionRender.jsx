
function ConditionRender() {
  const val = true;

  
  return (
    <>
    
      <p>{val ? "Hello Js" : "Welcome Js"}</p>
    </>
  );
}
export default ConditionRender;
ConditionRender.jsx

