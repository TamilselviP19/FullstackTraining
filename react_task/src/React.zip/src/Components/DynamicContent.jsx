

function DynamicContent() {
  const fruits = ["Apple", "Banana", "Mango", "Avocado", "Blueberry"];

  const filteredFruits = fruits.filter((fruit) => fruit.startsWith("A"));

  const sortedFilteredFruits = filteredFruits.sort();

  return (
    <>
      <h3>Original Fruit List:</h3>
      <ul>
        {fruits.map((fruit, index) => (
          <li key={index}>{fruit}</li>
        ))}
      </ul>

      <h3>Filtered & Sorted Fruits (Start with 'A'):</h3>
      <ul>
        {sortedFilteredFruits.map((fruit, index) => (
          <li key={index}>{fruit}</li>
        ))}
      </ul>
    </>
  );
}

export default DynamicContent;
