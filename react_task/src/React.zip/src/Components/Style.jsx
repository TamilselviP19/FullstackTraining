function Style() {
    const Divstyle = {
        backgroundColor: "pink",
        width: "100px",
        height: "100px",
    };

    return (
        <>
            <div style={{ width: "100px", height: "100px", backgroundColor: "Yellow" }}>
                Hii
            </div>
            <div style={Divstyle}>
                hello
            </div>
        </>
    );
}
export default Style;
