import { useParams } from "react-router-dom";

function User() {
  const { name } = useParams(); // Gets the dynamic part from URL

  return (
    <div>
      <h2>Hello, {name}!</h2>
    </div>
  );
}

export default User;
