import { createSlice } from '@reduxjs/toolkit';

const scoreSlice = createSlice({
  name: 'score',
  initialState: {
    score: 0,
  },
  reducers: {
    increaseScore: (state, action) => {
      state.score += action.payload;
    },
    resetScore: (state) => {
      state.score = 0;
    },
  },
});

export const { increaseScore, resetScore } = scoreSlice.actions;
export default scoreSlice.reducer;
