
import { useContext } from "react";
import UserContext from "../Components/UserContext";

function ClickEvent() {
  const userName = useContext(UserContext);

  function Click(e) {
    alert("You clicked the button!");
    console.log(e);
  }

  return (
    <>
      <button
        className="btn btn-primary"
        onClick={(event) => {
          Click(event);
        }}
      >
        Click
      </button>
      <h3>Hello, {userName}!</h3>
    </>
  );
}
export default ClickEvent;
