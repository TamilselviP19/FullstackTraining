import img2 from "../assets/2.jpg";
function Conatct(){
    return(
        <>
        <h1>This is contact is page</h1>
        <img src={img2} style={{ width: "300px", height: "300px" }}></img>
        </>
    )
}
export default Conatct