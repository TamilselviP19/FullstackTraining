import PropsDemo from "./Components/PropsDemo";
import ConditionRender from "./Components/ConditionRender";
import DynamicContent from "./Components/DynamicContent";
import ClickEvent from "./Components/ClickEvent";
import UseState from "./Components/UseState";
import UseRef from "./Components/UseRef";
import Parent from "./Components/Parent";
import Style from "./Components/Style";
import Cleanup from "./Components/Cleanup";
import Home from "./Components/Home";

function App() {
  return (
    <>
      <h2>Props</h2>
      <PropsDemo />
      <hr />
      <h2>Styles</h2>
      <Style />
      <hr />
      <h2>Condition Render</h2>
      <ConditionRender />
      <hr />
      <h2>Dynamic Content and Filter&Sort</h2>
      <DynamicContent />
      {/* <hr />
      <h2>Click Event</h2>
      <ClickEvent /> */}
      <hr />
      <h2>UseState and UseEffect</h2>
      <UseState price="299" />
      <hr />
      <h2>UseRef</h2>
      <UseRef />
      <hr />
      <h2>Method as props</h2>
      <Parent />
      <hr/>
      <h2>Cleanup</h2>
      <Cleanup/>
      <hr/>
      <h2>UseContext</h2>
      <Home/>
    </>
  );
}
export default App;
// import React from "react";
// import { useDispatch, useSelector } from "react-redux";
// import { increaseScore, resetScore } from "../src/Components/scoreSlice";
// import {
//   increment,
//   decrement,
//   reset,
//   UnDo,
//   toggleLike,
// } from "../src/Components/counterSlice";
// import { setInput } from "./Components/inputSlice";
// import UseState from "./Components/UseState";

// function App() {
//   const text = useSelector((state) => state.input.text);
//   const count = useSelector((state) => state.counter.value);
//   const score = useSelector((state) => state.score.score);
//   const dispatch = useDispatch();
//   const like = useSelector((state) => state.counter.like);
//   console.log({ like });
//   return (
//     <div style={{ textAlign: "center", marginTop: "100px" }}>
//       <h1> Redux Counter App</h1>
//       <h2>Count: {count}</h2>
//       <button onClick={() => dispatch(increment())}> Increment</button>
//       <button onClick={() => dispatch(decrement())}> Decrement</button>
//       <button onClick={() => dispatch(reset())}> Reset</button>
//       <button onClick={() => dispatch(UnDo())}>UnDo</button>
//       <button onClick={() => dispatch(toggleLike())}>Toggle Like</button>
//       <p>{like ? "❤️" : "💜"}</p>
//       <hr />
//       <div>
//         <h1> Score Tracker</h1>
//         <h2>Current Score: {score}</h2>

//         <div style={{ marginTop: 20 }}>
//           <button onClick={() => dispatch(increaseScore(1))}> +1</button>
//           <button onClick={() => dispatch(increaseScore(5))}> +5</button>
//           <button onClick={() => dispatch(increaseScore(10))}> +10</button>
//         </div>

//         <div style={{ marginTop: 20 }}>
//           <button onClick={() => dispatch(resetScore())}>Reset Score</button>
//         </div>
//       </div>
//       <hr/>
//       <div style={{ padding: 30, fontFamily: 'Arial' }}>
//       <h1> Character Counter</h1>
//       <input
//         type="text"
//         value={text}
//         onChange={(e) => dispatch(setInput(e.target.value))}
//         placeholder="Type something here..."
//         style={{ padding: 8, width: '300px', fontSize: '16px' }}
//       />

//       <p style={{ marginTop: 15 }}>
//         Character Count: <strong>{text.length}</strong>
//       </p>
//     </div>
//     </div>
//   );
// }

// export default App;
// import { BrowserRouter, Routes, Route } from "react-router-dom";
// import User from "../src/Components/User";
// import Home from "./Components/Home";
// import About from "./Components/About";

// function App() {
//   return (
//     <BrowserRouter>
//       <Routes>
//         <Route path="/" element={<About/>} />
//         <Route path="/User/:name" element={<User />} />
//       </Routes>
//     </BrowserRouter>
//   );
// }

// export default App;
